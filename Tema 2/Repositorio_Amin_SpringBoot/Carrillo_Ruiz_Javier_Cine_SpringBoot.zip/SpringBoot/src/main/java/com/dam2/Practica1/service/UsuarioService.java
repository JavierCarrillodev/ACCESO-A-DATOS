package com.dam2.Practica1.service;

import com.dam2.Practica1.DTO.UsuarioCreateUpdateDTO;
import com.dam2.Practica1.DTO.UsuarioDTO;
import com.dam2.Practica1.DTO.mappers.UsuarioMapper;
import com.dam2.Practica1.domain.Usuario;
import com.dam2.Practica1.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Service
public class UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private UsuarioMapper mapeo;

    public List<UsuarioDTO> listar() {
        return usuarioRepository.findAll()
                .stream()
                .map(mapeo::toDto)
                .toList();
    }

    public UsuarioDTO buscarPorId(Integer id) {
        Usuario usuario = usuarioRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Usuario no encontrado con id: " + id));
        return mapeo.toDto(usuario);
    }

    @Transactional
    public UsuarioDTO agregar(UsuarioCreateUpdateDTO dto) {
        Usuario usuario = mapeo.toEntity(dto);
        usuario = usuarioRepository.save(usuario);
        return mapeo.toDto(usuario);
    }

    @Transactional
    public UsuarioDTO actualizar(Integer id, UsuarioCreateUpdateDTO dto) {
        Usuario usuarioExistente = usuarioRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Usuario no encontrado con id: " + id));

        mapeo.updateEntity(dto, usuarioExistente);
        Usuario actualizado = usuarioRepository.save(usuarioExistente);
        return mapeo.toDto(actualizado);
    }

    @Transactional
    public void eliminar(Integer id) {
        if (!usuarioRepository.existsById(id)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Usuario no encontrado con id: " + id);
        }
        usuarioRepository.deleteById(id);
    }
}