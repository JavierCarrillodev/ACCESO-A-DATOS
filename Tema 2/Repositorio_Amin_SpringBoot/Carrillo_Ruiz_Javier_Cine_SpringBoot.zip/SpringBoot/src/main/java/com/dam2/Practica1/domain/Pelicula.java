package com.dam2.Practica1.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;
import java.util.List;

@Entity
@Table(name = "peliculas")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Pelicula {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 120)
    private String titulo;

    private int duracion;              // minutos

    @Column(name = "fecha_estreno")
    private LocalDate fechaEstreno;

    private String sinopsis;

    private int puntuacion;

    @ManyToOne
    @JoinColumn(name = "director_id") // FK en PELICULA
    private Director director;

    @ManyToMany
    @JsonIgnore
    @JoinTable(
            name = "pelicula_actores", // Tabla intermedia
            joinColumns = @JoinColumn(name = "pelicula_id"), // FK
            inverseJoinColumns = @JoinColumn(name = "actor_id") // FK de la otra entidad
    )
    private List<Actor> actores;

    @ManyToMany
    @JoinTable(
            name = "peliculas_categorias",
            joinColumns = @JoinColumn(name = "pelicula_id"),
            inverseJoinColumns = @JoinColumn(name = "categoria_id")
    )
    private List<Categoria> categorias;

    @ManyToMany
    @JoinTable(
            name = "peliculas_idiomas",
            joinColumns = @JoinColumn(name = "pelicula_id"),
            inverseJoinColumns = @JoinColumn(name = "idioma_id")
    )
    private List<Idioma> idiomas;

    @ManyToMany
    @JoinTable(
            name = "peliculas_plataformas",
            joinColumns = @JoinColumn(name = "pelicula_id"),
            inverseJoinColumns = @JoinColumn(name = "plataforma_id")
    )
    private List<Plataforma> plataformas;

    @OneToMany(mappedBy = "pelicula")
    private List<Critica> criticas;

    public void addActor(Actor actor){
        actores.add(actor);
        actor.getPeliculas().add(this);
    }

    public void addCategoria(Categoria categoria){
        categorias.add(categoria);
        categoria.getPeliculas().add(this);
    }

    public void addIdioma(Idioma idioma){
        idiomas.add(idioma);
        idioma.getPeliculas().add(this);
    }
}

