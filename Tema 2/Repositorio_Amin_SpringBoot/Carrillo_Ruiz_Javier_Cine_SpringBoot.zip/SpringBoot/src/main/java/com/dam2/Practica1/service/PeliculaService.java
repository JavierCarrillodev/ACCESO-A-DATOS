package com.dam2.Practica1.service;

import com.dam2.Practica1.DTO.PeliculaCreateUpdateDTO;
import com.dam2.Practica1.DTO.PeliculaDTO;
import com.dam2.Practica1.DTO.mappers.PeliculaMapper;
import com.dam2.Practica1.domain.Pelicula;
import com.dam2.Practica1.repository.PeliculaRepository;
import jakarta.transaction.Transactional;
import lombok.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.scheduling.annotation.Async;

import java.util.Random;
import java.util.concurrent.CompletableFuture;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Semaphore;
import java.util.stream.Stream;

import org.springframework.web.server.ResponseStatusException;

@Service
@Getter
public class PeliculaService {
    private final List<Pelicula> peliculas = new ArrayList<>();
    @Autowired
    private PeliculaRepository peliculaRepository;
    @Autowired
    private PeliculaMapper mapper;

    @Autowired
    private AsyncService asyncService;

    /*
    public PeliculaService() {
        peliculas.add(new Pelicula(1L, "Interstellar", 169, LocalDate.of(2014, 11, 7),
                "Exploradores espaciales buscan un nuevo hogar para la humanidad.",6,null,null,null));
        peliculas.add(new Pelicula(2L, "The Dark Knight", 152, LocalDate.of(2008, 7, 18),
                "Batman enfrenta al Joker en una lucha por el alma de Gotham.",4,null,null,null));
        peliculas.add(new Pelicula(3L, "Soul", 100, LocalDate.of(2020, 12, 25),
                "Un músico descubre el sentido de la vida más allá de la muerte.",5,null,null,null));
    }
    */

    public List<PeliculaDTO> devolverPeliculasPuntuacion(int puntuacionMinima){

        List<PeliculaDTO> peliculasFiltradas = new ArrayList<>();
        for(PeliculaDTO pelicula : this.listar()){
            if (pelicula.getValoracion() >= puntuacionMinima) peliculasFiltradas.add(pelicula);
        }
        return peliculasFiltradas;
    }

    public List<PeliculaDTO> listar() {
        return peliculaRepository.findAll()
                .stream()
                .map(mapper::toDto)
                .toList();
    }

    public PeliculaDTO buscarPorId(Long id) {
        Pelicula p = peliculaRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Película no encontrada con id: " + id));
        return mapper.toDto(p);
        /*
        * return peliculas.stream()                 // convierte la lista en un flujo de datos
        .filter(p -> p.getId().equals(id)) // se queda solo con las películas cuyo id coincide
        .findFirst()                       // toma la primera coincidencia (si existe)
        .orElse(null);                     // devuelve esa película o null si no hay
        * */
    }

    @Transactional
    // Agrega la película, si no es posible se revierte (transacctional)
    public PeliculaDTO agregar(PeliculaCreateUpdateDTO peliculaCreateUpdateDTO) {
        Pelicula peliculaGuardar = mapper.toEntity(peliculaCreateUpdateDTO);
        peliculaGuardar = peliculaRepository.save(peliculaGuardar);
        return mapper.toDto(peliculaGuardar);
    }

    @Transactional
    public PeliculaDTO actualizar(Long id, PeliculaCreateUpdateDTO peliculaCreateUpdateDTO) {
        Pelicula peliculaExistente = peliculaRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Película no encontrada con id: " + id));

        mapper.updateEntity(peliculaCreateUpdateDTO, peliculaExistente);

        Pelicula actualizada = peliculaRepository.save(peliculaExistente);
        return mapper.toDto(actualizada);
    }

    @Transactional
    public void eliminar(Long id) {
        boolean existe = peliculaRepository.existsById(id);
        if (!existe) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Película no encontrada con id: " + id);
        }
        peliculaRepository.deleteById(id);
    }



    public String tareaLenta(String titulo) {
        try {
            System.out.println("Iniciando tarea para " + titulo + " en " + Thread.currentThread().getName());
            Thread.sleep(3000); // simula proceso lento (3 segundos)
            System.out.println("Terminando tarea para " + titulo);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return "Procesada " + titulo;
    }

    @Async("taskExecutor")
    public CompletableFuture<String> tareaLenta2(String titulo) {
        try {
            System.out.println("Iniciando " + titulo + " en " + Thread.currentThread().getName());
            Thread.sleep(3000);
            System.out.println("Terminando " + titulo);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return CompletableFuture.completedFuture("Procesada " + titulo);
    }

    @Async("taskExecutor")
    public CompletableFuture<String> reproducir(String titulo) {
        try {
            long inicio = System.currentTimeMillis();
            System.out.println("Reproduciendo " + titulo + " en " + Thread.currentThread().getName());
            int milisegundosAleatorios = (new Random().nextInt(5)+1) * 1000;
            Thread.sleep(milisegundosAleatorios);
            long tiempoTotalReproduccion = System.currentTimeMillis() - inicio;
            System.out.println("Terminando " + titulo);

        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return CompletableFuture.completedFuture("Procesada " + titulo);
    }

    // Actividad 3
    public void importarCarpeta(String rutaCarpeta) throws IOException {
        long inicio = System.currentTimeMillis();
        List<CompletableFuture<Void>> futures = new ArrayList<>();
        try (Stream<Path> paths = Files.list(Paths.get(rutaCarpeta))) {
            paths.filter(Files::isRegularFile).forEach(path -> {
                String nombre = path.toString().toLowerCase();
                if (nombre.endsWith(".csv") || nombre.endsWith(".txt")) {
                    futures.add(asyncService.importarCsvAsync(path));
                } else if (nombre.endsWith(".xml")) {
                    futures.add(asyncService.importarXmlAsync(path));
                }
            });
        }
        // Esperaramos a que terminen todas las tareas asíncronas
        CompletableFuture.allOf(futures.toArray(new CompletableFuture[0])).join();

        long fin = System.currentTimeMillis();
        System.out.println("Importación completa en " + (fin - inicio) + " ms");
    }

    // Actividad 4
    public HashMap<String, Integer> votacion(int jurados) {
        ConcurrentHashMap<String, Integer> votacion = new ConcurrentHashMap<>();
        Semaphore sem = new Semaphore(5);

            long inicio = System.currentTimeMillis();

            // Limpiar el HashMap
            votacion.clear();

            List<PeliculaDTO> peliculasDTO = listar();

            for (PeliculaDTO pelicula : peliculasDTO) {
                votacion.put(pelicula.getTitulo(), 0);
            }

            List<CompletableFuture<Void>> tareas = new ArrayList<>();

            for (int i = 0; i < jurados; i++) {
                tareas.add(asyncService.votar(peliculas, i + 1, sem, votacion));
            }

            // Esperamos a que terminen
            CompletableFuture.allOf(tareas.toArray(new CompletableFuture[0])).join();

            System.out.println("Las votaciones de los oscar han sido cerradas, los resultados son: " + votacion);

            long fin = System.currentTimeMillis();
            long tiempoTotalSeg = (fin - inicio);

            System.out.println("Tiempo total de las votaciones " + tiempoTotalSeg + " milisegundos");

            // Devolvemos el HashMap con los resultados
        return new HashMap<>(votacion);
    }

}
