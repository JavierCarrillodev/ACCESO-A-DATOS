package com.dam2.Practica1.web;

import com.dam2.Practica1.DTO.SalaCreateUpdateDTO;
import com.dam2.Practica1.DTO.SalaDTO;
import com.dam2.Practica1.service.SalaService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/salas")
public class SalaController {

    @Autowired
    private SalaService salaService;

    @GetMapping("/lista")
    public List<SalaDTO> listar() {
        return salaService.listar();
    }

    @GetMapping("/{id}")
    public SalaDTO buscarPorId(@PathVariable Integer id) {
        return salaService.buscarPorId(id);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public SalaDTO agregar(@RequestBody @Valid SalaCreateUpdateDTO dto) {
        return salaService.agregar(dto);
    }

    @PutMapping("/{id}")
    public SalaDTO actualizar(@PathVariable Integer id, @RequestBody @Valid SalaCreateUpdateDTO dto) {
        return salaService.actualizar(id, dto);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void eliminar(@PathVariable Integer id) {
        salaService.eliminar(id);
    }
}
