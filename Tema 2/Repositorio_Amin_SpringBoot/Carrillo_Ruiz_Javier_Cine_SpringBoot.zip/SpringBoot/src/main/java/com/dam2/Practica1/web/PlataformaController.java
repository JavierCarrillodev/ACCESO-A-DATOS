package com.dam2.Practica1.web;

import com.dam2.Practica1.DTO.PlataformaCreateUpdateDTO;
import com.dam2.Practica1.DTO.PlataformaDTO;
import com.dam2.Practica1.service.PlataformaService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/plataformas")
@RequiredArgsConstructor
public class PlataformaController {

    private final PlataformaService service;

    @GetMapping("/lista")
    public List<PlataformaDTO> listar() {
        return service.listar();
    }

    @GetMapping("/{id}")
    public PlataformaDTO buscarPorId(@PathVariable Integer id) {
        return service.buscarPorId(id);
    }

    @PostMapping
    public PlataformaDTO agregar(@Valid @RequestBody PlataformaCreateUpdateDTO dto) {
        return service.agregar(dto);
    }

    @PutMapping("/{id}")
    public PlataformaDTO actualizar(@PathVariable Integer id, @Valid @RequestBody PlataformaCreateUpdateDTO dto) {
        return service.actualizar(id, dto);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Integer id) {
        service.eliminar(id);
    }
}