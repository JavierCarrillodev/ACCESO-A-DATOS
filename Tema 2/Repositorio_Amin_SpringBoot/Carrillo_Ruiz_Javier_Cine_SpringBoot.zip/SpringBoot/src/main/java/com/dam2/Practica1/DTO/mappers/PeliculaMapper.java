package com.dam2.Practica1.DTO.mappers;

import com.dam2.Practica1.DTO.PeliculaCreateUpdateDTO;
import com.dam2.Practica1.DTO.PeliculaDTO;
import com.dam2.Practica1.domain.Pelicula;
import org.springframework.stereotype.Component;

@Component
public class PeliculaMapper {

    // El método toDto(Pelicula pelicula) recibe una entidad Pelicula y devuelve un PeliculaDTO.
    public PeliculaDTO toDto(Pelicula pelicula) {
        if (pelicula == null) return null;
        return new PeliculaDTO(
                pelicula.getId(),
                pelicula.getTitulo(),
                pelicula.getDuracion(),
                pelicula.getFechaEstreno(),
                pelicula.getSinopsis(),
                pelicula.getPuntuacion()
        );
    }
    // El método toEntity(PeliculaCreateUpdateDTO dto) crea una nueva entidad Pelicula a partir del DTO que se usa para crear o editar películas.
    public Pelicula toEntity(PeliculaCreateUpdateDTO peliculaCreateUpdateDTO) {
        if (peliculaCreateUpdateDTO == null) return null;
        Pelicula pelicula = new Pelicula();
        pelicula.setTitulo(peliculaCreateUpdateDTO.getTitulo());
        pelicula.setDuracion(peliculaCreateUpdateDTO.getDuracion());
        pelicula.setFechaEstreno(peliculaCreateUpdateDTO.getFechaEstreno());
        pelicula.setSinopsis(peliculaCreateUpdateDTO.getSinopsis());
        pelicula.setPuntuacion(peliculaCreateUpdateDTO.getValoracion());
        return pelicula;
    }

    // Este método permite modificar una entidad ya existente con los datos de un DTO.
    public void updateEntity(PeliculaCreateUpdateDTO peliculaCreateUpdateDTO, Pelicula pelicula) {
        if (peliculaCreateUpdateDTO == null || pelicula == null) return;

        pelicula.setTitulo(peliculaCreateUpdateDTO.getTitulo());
        pelicula.setDuracion(peliculaCreateUpdateDTO.getDuracion());
        pelicula.setFechaEstreno(peliculaCreateUpdateDTO.getFechaEstreno());
        pelicula.setSinopsis(peliculaCreateUpdateDTO.getSinopsis());
        pelicula.setPuntuacion(peliculaCreateUpdateDTO.getValoracion());
    }
}