package com.dam2.Practica1.DTO.mappers;

import com.dam2.Practica1.DTO.PlataformaCreateUpdateDTO;
import com.dam2.Practica1.DTO.PlataformaDTO;
import com.dam2.Practica1.domain.Plataforma;
import org.springframework.stereotype.Component;

@Component
public class PlataformaMapper {

    // Convierte una entidad Plataforma en un PlataformaDTO.
    public PlataformaDTO toDto(Plataforma plataforma) {
        if (plataforma == null) return null;
        return new PlataformaDTO(plataforma.getId(), plataforma.getNombre(), plataforma.getUrl());
    }

    // Convierte un DTO de creación/actualización en una entidad nueva.
    public Plataforma toEntity(PlataformaCreateUpdateDTO dto) {
        if (dto == null) return null;
        Plataforma plataforma = new Plataforma();
        plataforma.setNombre(dto.getNombre());
        plataforma.setUrl(dto.getUrl());
        return plataforma;
    }

    // Actualiza una entidad existente con datos del DTO.
    public void updateEntity(PlataformaCreateUpdateDTO dto, Plataforma plataforma) {
        if (dto == null || plataforma == null) return;
        plataforma.setNombre(dto.getNombre());
        plataforma.setUrl(dto.getUrl());
    }
}