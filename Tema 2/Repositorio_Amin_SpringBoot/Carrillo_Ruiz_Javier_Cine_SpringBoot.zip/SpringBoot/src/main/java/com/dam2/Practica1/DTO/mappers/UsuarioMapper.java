package com.dam2.Practica1.DTO.mappers;

import com.dam2.Practica1.DTO.UsuarioCreateUpdateDTO;
import com.dam2.Practica1.DTO.UsuarioDTO;
import com.dam2.Practica1.domain.Usuario;
import org.springframework.stereotype.Component;

@Component
public class UsuarioMapper {

    // Convierte una entidad Usuario en un UsuarioDTO.
    public UsuarioDTO toDto(Usuario usuario) {
        if (usuario == null) return null;
        return new UsuarioDTO(
                usuario.getId(),
                usuario.getUsername(),
                usuario.getEmail(),
                usuario.getPassword()
        );
    }

    // Convierte un DTO en una nueva entidad Usuario.
    public Usuario toEntity(UsuarioCreateUpdateDTO dto) {
        if (dto == null) return null;
        Usuario usuario = new Usuario();
        usuario.setUsername(dto.getUsername());
        usuario.setEmail(dto.getEmail());
        usuario.setPassword(dto.getPassword());
        return usuario;
    }

    // Actualiza una entidad existente con los datos del DTO.
    public void updateEntity(UsuarioCreateUpdateDTO dto, Usuario usuario) {
        if (dto == null || usuario == null) return;
        usuario.setUsername(dto.getUsername());
        usuario.setEmail(dto.getEmail());
        usuario.setPassword(dto.getPassword());
    }
}