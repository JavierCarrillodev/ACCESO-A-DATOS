package com.dam2.Practica1.web;

import com.dam2.Practica1.DTO.FuncionCreateUpdateDTO;
import com.dam2.Practica1.DTO.FuncionDTO;
import com.dam2.Practica1.service.FuncionService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/funciones")
@RequiredArgsConstructor
public class FuncionController {

    private final FuncionService service;

    @GetMapping("/lista")
    public List<FuncionDTO> listar() {
        return service.listar();
    }

    @GetMapping("/{id}")
    public FuncionDTO buscarPorId(@PathVariable Integer id) {
        return service.buscarPorId(id);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public FuncionDTO agregar(@Valid @RequestBody FuncionCreateUpdateDTO dto) {
        return service.agregar(dto);
    }

    @PutMapping("/{id}")
    public FuncionDTO actualizar(@PathVariable Integer id, @Valid @RequestBody FuncionCreateUpdateDTO dto) {
        return service.actualizar(id, dto);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void eliminar(@PathVariable Integer id) {
        service.eliminar(id);
    }

}