package com.dam2.Practica1.repository;

import com.dam2.Practica1.domain.Funcion;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FuncionRepository extends JpaRepository<Funcion, Integer> {
}