package com.dam2.Practica1.service;

import com.dam2.Practica1.DTO.DirectorCreateUpdateDTO;
import com.dam2.Practica1.DTO.DirectorDTO;
import com.dam2.Practica1.DTO.mappers.DirectorMapper;
import com.dam2.Practica1.domain.Director;
import com.dam2.Practica1.repository.DirectorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Service
public class DirectorService {

    @Autowired
    private DirectorRepository directorRepository;

    @Autowired
    private DirectorMapper mapper;

    public List<DirectorDTO> listar() {
        return directorRepository.findAll()
                .stream()
                .map(mapper::toDto)
                .toList();
    }

    public DirectorDTO buscarPorId(Integer id) {
        Director director = directorRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Director no encontrado con id: " + id));
        return mapper.toDto(director);
    }

    @Transactional
    public DirectorDTO agregar(DirectorCreateUpdateDTO dto) {
        Director director = mapper.toEntity(dto);
        director = directorRepository.save(director);
        return mapper.toDto(director);
    }

    @Transactional
    public DirectorDTO actualizar(Integer id, DirectorCreateUpdateDTO dto) {
        Director directorExistente = directorRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Director no encontrado con id: " + id));

        mapper.updateEntity(dto, directorExistente);
        Director actualizado = directorRepository.save(directorExistente);
        return mapper.toDto(actualizado);
    }

    @Transactional
    public void eliminar(Integer id) {
        boolean existe = directorRepository.existsById(id);
        if (!existe) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Director no encontrado con id: " + id);
        }
        directorRepository.deleteById(id);
    }
}