package com.dam2.Practica1.service;

import com.dam2.Practica1.DTO.FuncionCreateUpdateDTO;
import com.dam2.Practica1.DTO.FuncionDTO;
import com.dam2.Practica1.DTO.mappers.FuncionMapper;
import com.dam2.Practica1.domain.Funcion;
import com.dam2.Practica1.repository.FuncionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Service
@RequiredArgsConstructor
public class FuncionService {

    private final FuncionRepository funcionRepository;
    private final FuncionMapper mapper;

    public List<FuncionDTO> listar() {
        return funcionRepository.findAll()
                .stream()
                .map(mapper::toDto)
                .toList();
    }

    public FuncionDTO buscarPorId(Integer id) {
        Funcion funcion = funcionRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Función no encontrada"));
        return mapper.toDto(funcion);
    }

    public FuncionDTO agregar(FuncionCreateUpdateDTO dto) {
        Funcion funcion = mapper.toEntity(dto);
        funcion = funcionRepository.save(funcion);
        return mapper.toDto(funcion);
    }

    public FuncionDTO actualizar(Integer id, FuncionCreateUpdateDTO dto) {
        Funcion existente = funcionRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "La función no se ha encontrado"));

        mapper.updateEntity(dto, existente);
        existente = funcionRepository.save(existente);

        return mapper.toDto(existente);
    }

    public void eliminar(Integer id) {
        if (!funcionRepository.existsById(id)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "La función no ha encontrado");
        }
        funcionRepository.deleteById(id);
    }
}