package com.dam2.Practica1.web;


import com.dam2.Practica1.DTO.PeliculaCreateUpdateDTO;
import com.dam2.Practica1.DTO.PeliculaDTO;
import com.dam2.Practica1.domain.Pelicula;
import com.dam2.Practica1.service.PeliculaService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.HashMap;
import java.util.concurrent.CompletableFuture;
import java.util.List;

@RestController
@RequestMapping("/api/peliculas")
@RequiredArgsConstructor
public class PeliculaController {
    private final PeliculaService service;

    @GetMapping("/lista")
    public List<PeliculaDTO> listar() {
        return service.listar();
    }

    @GetMapping("/{id}")
    public PeliculaDTO buscarPorId(@PathVariable Long id) {
        return service.buscarPorId(id);
    }

    @PostMapping
    public PeliculaDTO agregar(@Valid @RequestBody PeliculaCreateUpdateDTO pelicula) {
        return service.agregar(pelicula);
    }

    @PutMapping("/{id}")
    public PeliculaDTO actualizar(@PathVariable Long id, @Valid @RequestBody PeliculaCreateUpdateDTO pelicula) {
        return service.actualizar(id, pelicula);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id) {
        service.eliminar(id);
    }

    // Solo nos devuelve las películas con una puntuación mayor o igual a la que se requiere
    @GetMapping("/puntuacion/{puntuacion}")
    public List<PeliculaDTO> peliculasPuntuacionMinima (@PathVariable int puntuacion){
        return service.devolverPeliculasPuntuacion(puntuacion);
    }

/*
    @GetMapping("/mejores_peliculas")
    public List<Pelicula> mejores_peliculas() {
        return service.mejores_peliculas();
    }
*/


    @GetMapping("/procesar")
    public String procesarPeliculas() {
        long inicio = System.currentTimeMillis();
        service.tareaLenta("Interstellar");
        service.tareaLenta("The Dark Knight");
        service.tareaLenta("Soul");
        long fin = System.currentTimeMillis();
        return "Tiempo total: " + (fin - inicio) + " ms";
    }

    @GetMapping("/procesarAsync")
    public String procesarAsync() {
        long inicio = System.currentTimeMillis();

        var t1 = service.tareaLenta2("🍿 Interstellar");
        var t2 = service.tareaLenta2("🦇 The Dark Knight");
        var t3 = service.tareaLenta2("🎵 Soul");
        var t4 = service.tareaLenta2("🎵 Soul");
        var t5 = service.tareaLenta2("🎵 Soul");
        var t6 = service.tareaLenta2("🎵 Soul");
        //var t7 = service.tareaLenta2("🎵 Soul");

        // Espera a que terminen todas las tareas
        CompletableFuture.allOf(t1, t2, t3,t4,t5,t6).join();

        long fin = System.currentTimeMillis();
        return "Tiempo total (asíncrono): " + (fin - inicio) + " ms";
    }

    // A4 - Ejercicio 2
    @GetMapping("/reproducir")
    public String reproducirAsync() {
        long inicio = System.currentTimeMillis();

        var t1 = service.reproducir("🍿 Interstellar");
        var t2 = service.reproducir("🦇 The Dark Knight");
        var t3 = service.reproducir("🎵 Soul");

        // Espera a que terminen todas las tareas
        CompletableFuture.allOf(t1, t2, t3).join();

        long fin = System.currentTimeMillis();
        return "Tiempo total (asíncrono): " + (fin - inicio) + " ms";
    }

    // A4 - Ejercicio 3
    @PostMapping("/importarPeliculas/{nombreCarpeta}")
    public ResponseEntity<?> cargarPeliculas(@PathVariable String nombreCarpeta) throws IOException {
        String ruta = "src/main/resources/" + nombreCarpeta;

        service.importarCarpeta(ruta);
        return ResponseEntity.status(HttpStatus.CREATED).body("Ficheros importados");
    }

    //A4 - Ejercicio 4
    @GetMapping("/oscar/{numeroJurados}")
    public HashMap<String, Integer> votacion(@PathVariable int numeroJurados) throws InterruptedException {
        return service.votacion(numeroJurados);

    }


}
