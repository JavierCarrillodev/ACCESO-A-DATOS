package com.dam2.Practica1.DTO.mappers;

import com.dam2.Practica1.DTO.CriticaCreateUpdateDTO;
import com.dam2.Practica1.domain.Critica;
import org.springframework.stereotype.Component;

@Component
public class CriticaMapper {

    // Convierte una entidad Critica en un CriticaCreateUpdateDTO.
    public CriticaCreateUpdateDTO toDto(Critica critica) {
        if (critica == null) return null;
        CriticaCreateUpdateDTO dto = new CriticaCreateUpdateDTO();
        dto.setComentario(critica.getComentario());
        dto.setNota(critica.getNota());
        dto.setFecha(critica.getFecha());
        return dto;
    }

    // Convierte un DTO en una nueva entidad Critica.
    public Critica toEntity(CriticaCreateUpdateDTO dto) {
        if (dto == null) return null;
        Critica critica = new Critica();
        critica.setComentario(dto.getComentario());
        critica.setNota(dto.getNota());
        critica.setFecha(dto.getFecha());
        return critica;
    }

    // Actualiza una entidad existente con los datos del DTO.
    public void updateEntity(CriticaCreateUpdateDTO dto, Critica critica) {
        if (dto == null || critica == null) return;
        critica.setComentario(dto.getComentario());
        critica.setNota(dto.getNota());
        critica.setFecha(dto.getFecha());
    }
}