package com.dam2.Practica1.service;



import com.dam2.Practica1.DTO.ActorCreateUpdateDTO;
import com.dam2.Practica1.DTO.ActorDTO;
import com.dam2.Practica1.DTO.mappers.ActorMapper;
import com.dam2.Practica1.domain.Actor;
import com.dam2.Practica1.repository.ActorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Service
public class ActorService {

    @Autowired
    private ActorRepository actorRepository;

    @Autowired
    private ActorMapper mapper;

    // Listar todos los actores
    public List<ActorDTO> listar() {
        return actorRepository.findAll()
                .stream()
                .map(mapper::toDto)
                .toList();
    }

    // Buscamos un actor por id
    public ActorDTO buscarPorId(Integer id) {
        Actor actor = actorRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Actor no encontrado con id: " + id));
        return mapper.toDto(actor);
    }

    // Agregamos un nuevo actor
    @Transactional
    public ActorDTO agregar(ActorCreateUpdateDTO dto) {
        Actor actor = mapper.toEntity(dto);
        actor = actorRepository.save(actor);
        return mapper.toDto(actor);
    }

    // Se actualiza un actor existente
    @Transactional
    public ActorDTO actualizar(Integer id, ActorCreateUpdateDTO dto) {
        Actor actorExistente = actorRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Actor no encontrado con id: " + id));

        mapper.updateEntity(dto, actorExistente);
        Actor actualizado = actorRepository.save(actorExistente);
        return mapper.toDto(actualizado);
    }

    // Eliminamos un actor
    @Transactional
    public void eliminar(Integer id) {
        boolean existe = actorRepository.existsById(id);
        if (!existe) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Actor no encontrado con id: " + id);
        }
        actorRepository.deleteById(id);
    }
}