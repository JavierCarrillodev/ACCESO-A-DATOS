package com.dam2.Practica1.DTO.mappers;


import com.dam2.Practica1.DTO.DirectorCreateUpdateDTO;
import com.dam2.Practica1.DTO.DirectorDTO;
import com.dam2.Practica1.domain.Director;
import org.springframework.stereotype.Component;

@Component
public class DirectorMapper {

    // Convierte una entidad Director en un DirectorDTO.
    public DirectorDTO toDto(Director director) {
        if (director == null) return null;
        return new DirectorDTO(director.getId(), director.getNombre()
        );
    }

    // Convierte un DTO en una nueva entidad Director.
    public Director toEntity(DirectorCreateUpdateDTO dto) {
        if (dto == null) return null;
        Director director = new Director();
        director.setNombre(dto.getNombre());
        return director;
    }

    // Actualiza una entidad existente con los datos del DTO.
    public void updateEntity(DirectorCreateUpdateDTO dto, Director director) {
        if (dto == null || director == null) return;
        director.setNombre(dto.getNombre());
    }

}