package com.dam2.Practica1.repository;

import com.dam2.Practica1.domain.Sala;
import org.springframework.data.jpa.repository.JpaRepository;


public interface SalaRepository extends JpaRepository<Sala, Integer> {
}
