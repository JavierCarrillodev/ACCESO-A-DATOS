package com.dam2.Practica1.service;

import com.dam2.Practica1.DTO.SalaCreateUpdateDTO;
import com.dam2.Practica1.DTO.SalaDTO;
import com.dam2.Practica1.DTO.mappers.SalaMapper;
import com.dam2.Practica1.domain.Sala;
import com.dam2.Practica1.repository.SalaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Service
public class SalaService {

    @Autowired
    private SalaRepository salaRepository;

    @Autowired
    private SalaMapper mapeo;

    public List<SalaDTO> listar() {
        return salaRepository.findAll()
                .stream()
                .map(mapeo::toDto)
                .toList();
    }

    public SalaDTO buscarPorId(Integer id) {
        Sala sala = salaRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Sala no encontrada con id: " + id));
        return mapeo.toDto(sala);
    }

    @Transactional
    public SalaDTO agregar(SalaCreateUpdateDTO dto) {
        Sala sala = mapeo.toEntity(dto);
        sala = salaRepository.save(sala);
        return mapeo.toDto(sala);
    }

    @Transactional
    public SalaDTO actualizar(Integer id, SalaCreateUpdateDTO dto) {
        Sala existente = salaRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Sala no encontrada con id: " + id));

        mapeo.updateEntity(dto, existente);
        existente = salaRepository.save(existente);

        return mapeo.toDto(existente);
    }

    @Transactional
    public void eliminar(Integer id) {
        if (!salaRepository.existsById(id)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Sala no encontrada con id: " + id);
        }
        salaRepository.deleteById(id);
    }
}