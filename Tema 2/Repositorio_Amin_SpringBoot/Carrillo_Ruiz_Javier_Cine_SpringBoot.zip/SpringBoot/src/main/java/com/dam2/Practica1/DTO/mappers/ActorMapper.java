package com.dam2.Practica1.DTO.mappers;



import com.dam2.Practica1.DTO.ActorCreateUpdateDTO;
import com.dam2.Practica1.DTO.ActorDTO;
import com.dam2.Practica1.domain.Actor;
import org.springframework.stereotype.Component;

@Component
public class ActorMapper {

   // Convierte una entidad Actor en un ActorDTO.
    public ActorDTO toDto(Actor actor) {
        if (actor == null) return null;
        return new ActorDTO(actor.getId(), actor.getNombre()
        );
    }

    // Convierte un DTO en una nueva entidad Actor.
    public Actor toEntity(ActorCreateUpdateDTO dto) {
        if (dto == null) return null;
        Actor actor = new Actor();
        actor.setNombre(dto.getNombre());
        return actor;
    }

    // Actualiza una entidad existente con los datos del DTO.
    public void updateEntity(ActorCreateUpdateDTO dto, Actor actor) {
        if (dto == null || actor == null) return;
        actor.setNombre(dto.getNombre());
    }
}