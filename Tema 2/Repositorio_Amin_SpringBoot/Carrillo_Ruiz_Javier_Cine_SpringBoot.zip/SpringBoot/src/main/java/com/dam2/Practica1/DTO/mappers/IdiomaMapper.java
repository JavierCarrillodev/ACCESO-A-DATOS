package com.dam2.Practica1.DTO.mappers;

import com.dam2.Practica1.DTO.IdiomaCreateUpdateDTO;
import com.dam2.Practica1.DTO.IdiomaDTO;
import com.dam2.Practica1.domain.Idioma;
import org.springframework.stereotype.Component;

@Component
public class IdiomaMapper {

    // Convierte una entidad Idioma en un IdiomaDTO.
    public IdiomaDTO toDto(Idioma idioma) {
        if (idioma == null) return null;
        return new IdiomaDTO(idioma.getId(), idioma.getNombre());
    }

    // Convierte un DTO en una nueva entidad Idioma.
    public Idioma toEntity(IdiomaCreateUpdateDTO dto) {
        if (dto == null) return null;
        Idioma idioma = new Idioma();
        idioma.setNombre(dto.getNombre());
        return idioma;
    }

    // Actualiza una entidad existente con los datos del DTO.
    public void updateEntity(IdiomaCreateUpdateDTO dto, Idioma idioma) {
        if (dto == null || idioma == null) return;
        idioma.setNombre(dto.getNombre());
    }
}