package com.dam2.Practica1.DTO.mappers;


import com.dam2.Practica1.DTO.CategoriaCreateUpdateDTO;
import com.dam2.Practica1.DTO.CategoriaDTO;
import com.dam2.Practica1.domain.Categoria;
import org.springframework.stereotype.Component;

@Component
public class CategoriaMapper {

    // Convierte una entidad Categoria en un CategoriaDTO.
    public CategoriaDTO toDto(Categoria categoria) {
        if (categoria == null) return null;
        return new CategoriaDTO(categoria.getId(), categoria.getNombre()
        );
    }

    // Convierte un DTO en una nueva entidad Categoria.
    public Categoria toEntity(CategoriaCreateUpdateDTO dto) {
        if (dto == null) return null;
        Categoria categoria = new Categoria();
        categoria.setNombre(dto.getNombre());
        return categoria;
    }

    // Actualiza una entidad existente con los datos del DTO.
    public void updateEntity(CategoriaCreateUpdateDTO dto, Categoria categoria) {
        if (dto == null || categoria == null) return;
        categoria.setNombre(dto.getNombre());
    }
}