package com.dam2.Practica1.web;

import com.dam2.Practica1.DTO.CriticaCreateUpdateDTO;
import com.dam2.Practica1.service.CriticaService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/criticas")
@RequiredArgsConstructor
public class CriticaController {

    private final CriticaService service;

    @GetMapping
    public List<CriticaCreateUpdateDTO> listar() {
        return service.listar();
    }

    @GetMapping("/{id}")
    public CriticaCreateUpdateDTO buscarPorId(@PathVariable Integer id) {
        return service.buscarPorId(id);
    }

    @PostMapping
    public CriticaCreateUpdateDTO agregar(@Valid @RequestBody CriticaCreateUpdateDTO dto) {
        return service.agregar(dto);
    }

    @PutMapping("/{id}")
    public CriticaCreateUpdateDTO actualizar(@PathVariable Integer id, @Valid @RequestBody CriticaCreateUpdateDTO dto) {
        return service.actualizar(id, dto);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Integer id) {
        service.eliminar(id);
    }

}