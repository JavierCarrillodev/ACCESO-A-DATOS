package com.dam2.Practica1.web;

import com.dam2.Practica1.DTO.IdiomaCreateUpdateDTO;
import com.dam2.Practica1.DTO.IdiomaDTO;
import com.dam2.Practica1.service.IdiomaService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/idiomas")
@RequiredArgsConstructor
public class IdiomaController {

    private final IdiomaService service;

    @GetMapping
    public List<IdiomaDTO> listar() {
        return service.listar();
    }

    @GetMapping("/{id}")
    public IdiomaDTO buscarPorId(@PathVariable Integer id) {
        return service.buscarPorId(id);
    }

    @PostMapping
    public IdiomaDTO agregar(@Valid @RequestBody IdiomaCreateUpdateDTO dto) {
        return service.agregar(dto);
    }

    @PutMapping("/{id}")
    public IdiomaDTO actualizar(@PathVariable Integer id, @Valid @RequestBody IdiomaCreateUpdateDTO dto) {
        return service.actualizar(id, dto);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Integer id) {
        service.eliminar(id);
    }
}