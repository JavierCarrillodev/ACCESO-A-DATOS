package com.dam2.Practica1.web;

import com.dam2.Practica1.DTO.ActorCreateUpdateDTO;
import com.dam2.Practica1.DTO.ActorDTO;
import com.dam2.Practica1.service.ActorService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/actores")
@RequiredArgsConstructor
public class ActorController {

    private final ActorService service;

    // Se devuelve todos los actores
    @GetMapping
    public List<ActorDTO> listar() {
        return service.listar();
    }

    // Se devuelve ActorDTO
    @GetMapping("/{id}")
    public ActorDTO buscarPorId(@PathVariable Integer id) {
        return service.buscarPorId(id);
    }

    // Recibe ActorCreateUpdateDTO, se devuelve ActorDTO
    @PostMapping
    public ActorDTO agregar(@Valid @RequestBody ActorCreateUpdateDTO actor) {
        return service.agregar(actor);
    }

    // Recibimos ActorCreateUpdateDTO, se devuelve ActorDTO
    @PutMapping("/{id}")
    public ActorDTO actualizar(@PathVariable Integer id, @Valid @RequestBody ActorCreateUpdateDTO actor) {
        return service.actualizar(id, actor);
    }

    // Elimina un actor
    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Integer id) {
        service.eliminar(id);
    }

}