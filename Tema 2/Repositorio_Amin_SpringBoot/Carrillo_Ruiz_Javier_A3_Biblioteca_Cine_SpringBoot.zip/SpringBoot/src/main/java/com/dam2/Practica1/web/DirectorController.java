package com.dam2.Practica1.web;

import com.dam2.Practica1.DTO.DirectorCreateUpdateDTO;
import com.dam2.Practica1.DTO.DirectorDTO;
import com.dam2.Practica1.service.DirectorService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/directores")
@RequiredArgsConstructor
public class DirectorController {

    private final DirectorService service;

    //  Devolvemos todos los directores
    @GetMapping
    public List<DirectorDTO> listar() {
        return service.listar();
    }

    // Se devuelve un director por id
    @GetMapping("/{id}")
    public DirectorDTO buscarPorId(@PathVariable Integer id) {
        return service.buscarPorId(id);
    }

    // Recibe DirectorCreateUpdateDTO, se devuelve DirectorDTO
    @PostMapping
    public DirectorDTO agregar(@Valid @RequestBody DirectorCreateUpdateDTO director) {
        return service.agregar(director);
    }

    // Recibe DirectorCreateUpdateDTO, se devuelve DirectorDTO
    @PutMapping("/{id}")
    public DirectorDTO actualizar(@PathVariable Integer id, @Valid @RequestBody DirectorCreateUpdateDTO director) {
        return service.actualizar(id, director);
    }

    // Elimina un director
    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Integer id) {
        service.eliminar(id);
    }
}